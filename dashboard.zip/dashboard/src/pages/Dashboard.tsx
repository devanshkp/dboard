import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart3 } from 'lucide-react';
import AppointmentCard from '../components/AppointmentCard';
import TranscriptPanel from '../components/TranscriptPanel';
import { appointments } from '../data/mockData';

const Dashboard = () => {
  const navigate = useNavigate();
  const [selectedAppointmentId, setSelectedAppointmentId] = useState<string>(appointments[0].id);

  const selectedAppointment = appointments.find(a => a.id === selectedAppointmentId) || appointments[0];

  // Group appointments by date
  const groupedAppointments = useMemo(() => {
    const groups: Record<string, typeof appointments> = {};
    
    appointments.forEach(apt => {
      if (!groups[apt.date]) {
        groups[apt.date] = [];
      }
      groups[apt.date].push(apt);
    });

    // Sort dates and return as array of [date, appointments]
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  }, []);

  const formatDateHeader = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const isToday = date.toDateString() === today.toDateString();
    const isTomorrow = date.toDateString() === tomorrow.toDateString();

    const formatted = date.toLocaleDateString('en-AU', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
    });

    if (isToday) return `Today — ${formatted}`;
    if (isTomorrow) return `Tomorrow — ${formatted}`;
    return formatted;
  };

  // Find first appointment overall for "Next" badge
  const firstAppointmentId = appointments[0]?.id;

  return (
    <div>
      {/* Header */}
      <div className="mb-8 flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            Scheduled Appointments
          </h1>
          <p className="text-slate-500 mt-1">
            You have {appointments.length} meetings booked via Westpac AI Assistant.
          </p>
        </div>
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Grouped List */}
        <div className="lg:col-span-2 space-y-6">
          {groupedAppointments.map(([date, dateAppointments]) => (
            <div key={date}>
              <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide mb-3">
                {formatDateHeader(date)}
              </h2>
              <div className="space-y-3">
                {dateAppointments.map((apt) => (
                  <AppointmentCard 
                    key={apt.id} 
                    appointment={apt} 
                    isNext={apt.id === firstAppointmentId}
                    isSelected={selectedAppointmentId === apt.id}
                    onClick={() => setSelectedAppointmentId(apt.id)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Right: Details */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 mt-8">
            <TranscriptPanel appointment={selectedAppointment} previewMode={true} />
          </div>
        </div>
      </div>

      {/* Analytics Link */}
      <div className="mt-12 pt-6 border-t border-slate-200">
        <button
          onClick={() => navigate('/analytics')}
          className="flex items-center gap-2 text-slate-400 hover:text-slate-600 text-sm transition"
        >
          <BarChart3 size={16} />
          <span>View Callbot Analytics</span>
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
